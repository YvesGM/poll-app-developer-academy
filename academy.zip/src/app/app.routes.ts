import { Routes } from '@angular/router';

import { PollListComponent } from './features/polls/pages/poll-list/poll-list.component';
import { PollCreateComponent } from './features/polls/pages/poll-create/poll-create.component';
import { PollDetailComponent } from './features/polls/pages/poll-detail/poll-detail.component';

export const routes: Routes = [
  {
    path: '',
    component: PollListComponent,
  },
  {
    path: 'polls/new',
    component: PollCreateComponent,
  },
  {
    path: 'polls/:id',
    component: PollDetailComponent,
  },
  {
    path: '**',
    redirectTo: '',
  },
];